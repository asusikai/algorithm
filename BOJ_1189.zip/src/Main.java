import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.LinkedList;
import java.util.Queue;
import java.util.StringTokenizer;

public class Main {

    static int R;
    static int C;
    static int K;

    static char[][] map;

    static class pos{
        private int y;
        private int x;
        private int move;

        pos(int y, int x, int move){
            this.y = y;
            this.x = x;
            this.move = move;
        }
    }

    static int[] dy = {-1,0,1,0};
    static int[] dx = {0,1,0,-1};

    static int answer = 0;
    static void bfs(){

        Queue<pos> posQueue = new LinkedList<pos>();
        posQueue.add(new pos(R-1,C-1, 0));
        boolean[][] visited = new boolean[R][C];

        while(!posQueue.isEmpty()){
            pos current = posQueue.poll();

            if(current.move == K) {
                if(current.y == 0 && current.x == C-1){
                    answer++;
                }
                continue;
            }

            int y = current.y;
            int x = current.x;

            for(int i = 0; i<4; i++){
                int ny = y+dy[i];
                int nx = x+dx[i];

                if(ny<0 || ny>=R || nx<0 || nx>=C){
                    continue;
                }

                if(map[ny][nx] != '.'){
                    continue;
                }


            }

        }

    }

    public static void main(String[] args) throws Exception{
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        StringTokenizer st = new StringTokenizer(br.readLine()," ");
        R = Integer.parseInt(st.nextToken());
        C = Integer.parseInt(st.nextToken());
        K = Integer.parseInt(st.nextToken());

        map = new char[R][C];

        for(int i = 0; i<R; i++){
            String line = br.readLine();

            for(int j=0; j<C; j++){
                map[i][j] = line.charAt(j);
            }
        }



    }
}